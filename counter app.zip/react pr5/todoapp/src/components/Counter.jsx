import React, { useState } from "react";
const Counter=()=>{
    const[count,setcount]=useState(0);
    const handleincre=()=>{
            setcount(count+1)
    }
    const handledec=()=>{
            setcount(count-1)
    }
    return (
    <div>
        <h1>{count}</h1>
        <button onClick={()=>{
            handleincre()
        }}>increment</button>
        <button onClick={()=>{
            handledec()
        }}>decrement</button>

        {
            count===0?<div>count value is zero</div>:count>0?<div>count value is positive</div>:<div>count value is negative</div>
        }
    </div> )
}
export default Counter;